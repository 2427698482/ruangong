<?php
/**
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2019/5/13
 * Time: 20:21
 * @copyright: ©2019 .浙江禾匠信息科技
 * @link: http://www.zjhejiang.com
 */
?>
<p>尊敬的:<b><?= $mall->name; ?></b></p>
<h1>您有一个新的退款订单</h1>
<p>请及时进入商城处理</p>
