<?php
/**
 * @copyright ©2018 .浙江禾匠信息科技
 * @author Lu Wei
 * @link http://www.zjhejiang.com/
 * Created by IntelliJ IDEA
 * Date Time: 2018/12/11 12:02
 */


namespace app\core\payment;


use app\models\Model;

class PaymentOrderModel extends Model
{
    public $orderNo;

}