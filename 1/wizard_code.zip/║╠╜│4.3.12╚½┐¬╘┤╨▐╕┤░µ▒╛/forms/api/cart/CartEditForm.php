<?php

namespace app\forms\api\cart;

class CartEditForm extends CartEditBase
{

}
