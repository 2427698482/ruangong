<?php


namespace app\forms\api\poster;


interface BasePoster
{
    public function get();
}