<?php

namespace app\forms\common\grafika;

use app\models\Model;

abstract class BaseGrafika extends Model
{

}
