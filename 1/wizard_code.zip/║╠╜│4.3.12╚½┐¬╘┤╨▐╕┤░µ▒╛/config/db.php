<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'ky',
    'username' => 'ky',
    'password' => 'ky',
    'tablePrefix' => 'zjhj_bd_',
];
